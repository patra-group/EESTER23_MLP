#!/bin/bash
rm train.txt test.txt
rm *.png
awk '{if(NR>1)print($4 " " $5)}' ../02-train/energies.train.0 >> train.txt
awk '{if(NR>1)print($4 " " $5)}' ../02-train/energies.test.0 >> test.txt
#for i in {0..39}
#do
#    awk '{if(NR>1)print($4 " " $5)}' ../../02-train/energies.train.$i >> train.txt
#    awk '{if(NR>1)print($4 " " $5)}' ../../02-train/energies.test.$i >> test.txt
#done
#sed -n '224,+202p' ../output/train.out > errorval.txt 
gnuplot meanerror.gpi
