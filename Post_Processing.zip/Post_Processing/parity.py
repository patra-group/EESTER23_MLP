import os
cwd = os.getcwd()
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt
from io import BytesIO
from sklearn import linear_model

file1 = cwd + '/train.txt'
df1 = pd.read_csv(file1, sep=" ", skiprows=0 ,names=["x", "y"], header=None)
file2 = cwd + '/test.txt'
df2 = pd.read_csv(file2, sep=" ", skiprows=0 ,names=["x1", "y1"], header=None)

x= df1['x'].values.reshape(-1,1)
y= df1['y'].values.reshape(-1,1)

x2 = df2['x1'].values.reshape(-1,1)
y2 = df2['y1'].values.reshape(-1,1)

mergeX = []
mergeX.extend(x)
mergeX.extend(x2)
mergeY = []
mergeY.extend(y)
mergeY.extend(y2)

a = [-9,-5]
b = [-9,-5]

################################################ Train #############################################

ols = linear_model.LinearRegression()
model = ols.fit(mergeX, mergeY)
response = model.predict(mergeY)

############################################## Evaluate ############################################

r2 = model.score(mergeX, mergeY)

fig, ax = plt.subplots(figsize=(7, 7),dpi=300)
ax.plot(a,b, '--', color='black')
ax.scatter(x, y, edgecolor='k', facecolor='yellow', alpha=0.7, label='Training Set')
ax.scatter(x2, y2, edgecolor='k', facecolor='cyan', alpha=0.7, label='Testing Set')
ax.set_ylabel('Predicted Energy', fontsize=20, fontweight='bold')
ax.set_xlabel('Actual Energy', fontsize=20, fontweight='bold')
ax.legend(facecolor='white', fontsize=20)
plt.minorticks_off()
ax.text(0.8, 0.1, '$R^2= %.4f$' % r2, fontsize=20, horizontalalignment='center', verticalalignment='top', transform=ax.transAxes)
ax.tick_params(axis='both',which='major',labelsize=20)
fig.tight_layout()
fig.savefig("PARITY", bbox_inches="tight",pad_inches=0.0, transparent=True)
png1 = BytesIO()
fig.savefig(png1, format='jpeg', transparent=False)
png2 = Image.open(png1)
fig.show()
